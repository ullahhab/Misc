package clicker.game

import akka.actor.Actor



class GameActor(username: String, configuration: String) extends Actor {

  val conf: String = configuration
  val name: String = name

  case object Click
  case object Update
  case object BuyEquipment

  def getconf(): String ={
    conf
  }
  def getname(): String = {
    name
  }

  override def receive: Receive = {

    conf <-List(JASON.parsefull(configuration))
    case Click =>

    case Update =>

    case BuyEquipment =>

  }

  object Equipment{
    def equipment(configuration: String): Unit ={

    }
  }

}
