package solver

import maze.GridLocation

import scala.collection.immutable.Queue
import scala.util.control.Breaks
import scala.util.control.Breaks.breakable

object BFS {

  def bfs[A](graph: Graph[A], startID: Int, endID:Int): List[Int] = {

    var explored: Set[Int] = Set(startID)

    var distance: Map[Int, Int] = Map()
    distance += startID -> -1


    val toExplore: Queue[Int] = Queue()
    toExplore.enqueue(startID)

    while (!toExplore.empty()) {
      var nodeToExplore = toExplore.dequeue
      for (node <- graph.adjacencyList(nodeToExplore)) {
        if(!explored.contains(node)) {
          println("exploring: " + graph.nodes(node))
          distance += node -> nodeToExplore
          toExplore.enqueue(node)
          explored = explored + node
        }
      }
    }

  }

}
