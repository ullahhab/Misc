package solver


import maze.{GameMap, GridLocation, MapTile, PhysicsVector}
import solver.{Graph}



object PathFinding {
  val vel: Int = 5
  var index: Int = 0
  /*val graph: solver.Graph[GridLocation] = new Graph[GridLocation]
  var map:GameMap = GameMap.apply()
  for(i <- map.tiles){
    for(j <- i){
      if(j.tileType == "ground"){
        graph.addNode(index, j.tileType)
      }
    }
  }*/


  def findPath(start: GridLocation, end: GridLocation, map: List[List[MapTile]]): List[GridLocation] = {
    val graph: solver.Graph[GridLocation] = new Graph[GridLocation]
    var location: GridLocation = new GridLocation(0, 0)
    var x: Int = 0
    var y: Int = 0
    var start_index: Int = 0
    var end_index: Int = 0
    var map: GameMap = GameMap.apply()
    for (i <- map.tiles) {
      y += 1
      location = new GridLocation(x, y)
      for (j <- i) {
        index += 1
        if (j.tileType == "ground") {
          graph.addNode(index, location)
          if (graph.nodes.contains(index - 30)) {
            graph.addEdge(index - 30, index)
          }
          if (graph.nodes.contains(index - 1)) {
            graph.addEdge(index - 1, index)
          }
          if (location == start) {
            start_index = index
          }
          if (location == end) {
            end_index = index
          }
        }

        x += 1
        location = new GridLocation(x, y)

      }
    }
    var result: List[GridLocation] = new List()
    result = BFS.bfs(graph, start_index, end_index)
    result

  }

  def getVelocity(path: List[GridLocation], currentLocation: PhysicsVector): PhysicsVector = {
    var result:PhysicsVector = new PhysicsVector(0,0,0)
    var control: Boolean = false
    for (location <- path) {
      if(location.x ==currentLocation.x && location.y == currentLocation.y){
        control =true
      }
      if(control) {
        var pv: PhysicsVector = new PhysicsVector(location.x - 0.5, location.y - 0.5, 0.0)
        if(path.last.x == currentLocation.x && path.last.y ==currentLocation.y && currentLocation.distance2d(pv)==0.1){
          currentLocation.x =0.0
          currentLocation.y = 0.0
          currentLocation
        }
        else {
          currentLocation.distance2d(pv)
          currentLocation.normal2d()
          currentLocation.x = currentLocation.x * 5
          currentLocation.y = currentLocation.y * 5
          currentLocation
        }
      }
    }
    currentLocation
  }
}
